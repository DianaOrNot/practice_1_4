public class Doctor {
    private String name;
    private int age;
    private int salary;

    public Doctor(String name) {
        this.name = name;
    }

    public Doctor(String name, int age, int salary) {
        this.name = name;
        this.age = age;
        this.salary = salary;
    }

    public void work(int hours){
        System.out.println("Doctor works " + hours + "hours");
    }
    public void job(String[] prof){
        System.out.println("Doctor's speciality is " + prof);
    }
    public void experience(String[] years){
        System.out.println("Doctor's experience is " + years);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        if(salary < 0 || salary > 1000000) {
            this.salary = 50000;
        }else{
            this.salary = salary;
        }

    }

    public void setAge(int age) {
        if(age < 0 || age > 100){
            this.age = 18;
        }else{
            this.age = age;
        }



    }
}
