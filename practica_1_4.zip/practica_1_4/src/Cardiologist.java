public class Cardiologist extends Doctor{
    public String hospital;
    public int numberOfPatients;
    boolean stillWorks;
    public Cardiologist(String hospital, int numberOfPatients, boolean stillWorks, String name){
        super(name);
        this.hospital = hospital;
        this.numberOfPatients = numberOfPatients;
        this.stillWorks = stillWorks;
    }
    public String toString(){
        return "Surgeon(name = " + getName() + ", age = " + getAge() + ", salary = " + getSalary() +
                ", hospital = " + this.hospital +
                ", numberOfPatients = " + this.numberOfPatients +
                ", stillWorks = " + this.stillWorks + ")";
    }
    public void treatment(String treat){
        System.out.println("Cardiologist treats " + treat);
    }
    public void cabinet(int cab){
        System.out.println("Cardiologist's cabinet is №" + cab);
    }
    public void daysPerWeek(int days){
        System.out.println("Cardiologist works " + days + " per week");
    }
}
