import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        System.out.println("Мазитова Диана, РИБО-01-21, практика 1_4");
        System.out.println("Object of what class to create? 1 - Surgeon, 2 - Cardiologist");
        Scanner scanner = new Scanner(System.in);


        int a = scanner.nextInt();
        while (a != 1 && a != 2) {
            System.out.println("Enter again:");
        }
        if (a == 1) {
            System.out.println("Enter name:");
            String str = scanner.nextLine();
            scanner.nextLine();
            Doctor doc = new Doctor(str);
            System.out.println("Enter age:");
            int age = scanner.nextInt();
            System.out.println("Enter salary:");
            int salary = scanner.nextInt();
            System.out.println("Enter direction:");
            String direction = scanner.nextLine();
            scanner.nextLine();
            System.out.println("Enter a number of patients:");
            int number = scanner.nextInt();
            System.out.println("Enter the condition of work:");
            boolean stillWorks = scanner.hasNext();

            Surgeon surg = new Surgeon(direction, number, stillWorks, str);
            surg.setName(str);
            surg.setAge(age);
            surg.setSalary(salary);

            System.out.println(surg.toString());
        } else if (a == 2) {
            System.out.println("Enter name:");
            String str = scanner.nextLine();
            scanner.nextLine();
            Doctor doc = new Doctor(str);
            System.out.println("Enter age:");
            int age = scanner.nextInt();
            System.out.println("Enter salary:");
            int salary = scanner.nextInt();
            System.out.println("Enter hospital:");
            String hosp = scanner.nextLine();
            scanner.nextLine();
            System.out.println("Enter a number of patients:");
            int number = scanner.nextInt();
            System.out.println("Enter the condition of work:");
            boolean stillWorks = scanner.hasNext();

            Cardiologist cardio = new Cardiologist(hosp, number, stillWorks, str);
            cardio.setName(str);
            cardio.setAge(age);
            cardio.setSalary(salary);
        }

    }

}