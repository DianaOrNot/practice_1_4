public class Surgeon extends Doctor{
    private String direction;//направление специальности
    private int numberOfPatients;
    boolean stillWorks;//работает ли
    public Surgeon(String direction, int numberOfPatients, boolean stillWorks, String name){
        super(name);
        this.direction = direction;
        this.numberOfPatients = numberOfPatients;
        this.stillWorks = stillWorks;
    }
    public String toString(){
        return "Surgeon(name = " + getName() + ", age = " + getAge() + ", salary = " + getSalary() +
                ", direction = " + this.direction +
                ", numberOfPatients = " + this.numberOfPatients +
                ", stillWorks = " + this.stillWorks + ")";
    }

    public void hospital(String hosp){
        System.out.println("Surgeon works in " + hosp);
    }
    public void organ(String org){
        System.out.println("Surgeon operates " + org);
    }
    public void operation(int oper){
        System.out.println("Surgeon conducts " + oper + " per day");
    }
}
